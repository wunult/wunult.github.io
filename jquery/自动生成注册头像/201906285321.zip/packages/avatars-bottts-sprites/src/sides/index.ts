import antenna01 from './antenna-01';
import antenna02 from './antenna-02';
import cables01 from './cables-01';
import cables02 from './cables-02';
import round from './round';
import squareAssymetric from './square-assymetric';
import square from './square';

export default [antenna01, antenna02, cables01, cables02, round, squareAssymetric, square];
