export default () => `
    <rect x="28" y="10" width="6" height="14" rx="2" fill="black" fill-opacity="0.6"/>
    <rect x="14" y="10" width="6" height="14" rx="2" fill="black" fill-opacity="0.6"/>
    <rect x="42" y="10" width="6" height="14" rx="2" fill="black" fill-opacity="0.6"/>
    <rect x="56" y="10" width="6" height="14" rx="2" fill="black" fill-opacity="0.6"/>
`;
