export default () => `
    <rect x="12" y="12" width="4" height="8" rx="2" fill="black" fill-opacity="0.6"/>
    <rect x="36" y="12" width="4" height="8" rx="2" fill="black" fill-opacity="0.6"/>
    <rect x="24" y="12" width="4" height="8" rx="2" fill="black" fill-opacity="0.6"/>
    <rect x="48" y="12" width="4" height="8" rx="2" fill="black" fill-opacity="0.6"/>
    <rect x="60" y="12" width="4" height="8" rx="2" fill="black" fill-opacity="0.6"/>
`;
