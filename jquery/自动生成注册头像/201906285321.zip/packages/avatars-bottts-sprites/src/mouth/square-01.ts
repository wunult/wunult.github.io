export default () => `
    <rect x="24" y="6" width="27" height="8" rx="4" fill="black" fill-opacity="0.8"/>
`;
