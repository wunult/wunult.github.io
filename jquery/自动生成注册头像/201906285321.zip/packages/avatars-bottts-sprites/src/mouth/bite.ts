export default () => `
    <rect x="4" y="5" width="68" height="22" rx="5" fill="black" fill-opacity="0.2"/>
    <rect x="8" y="9" width="60" height="14" rx="2" fill="black" fill-opacity="0.6"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M20 17L26 9H14L20 17Z" fill="#E1E6E8"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M32 17L38 9H26L32 17Z" fill="#E1E6E8"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M44 17L50 9H38L44 17Z" fill="#E1E6E8"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M56 17L62 9H50L56 17Z" fill="#E1E6E8"/>
`;
