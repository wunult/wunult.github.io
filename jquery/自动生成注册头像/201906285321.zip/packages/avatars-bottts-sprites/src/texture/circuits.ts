export default () => `
    <path fill-rule="evenodd" clip-rule="evenodd" d="M15 0H11V18H15V0ZM23 0H19V30V34H23H72.416C73.1876 35.7659 74.9497 37 77 37C79.7614 37 82 34.7614 82 32C82 29.2386 79.7614 27 77 27C74.9497 27 73.1876 28.2341 72.416 30H23V0Z" fill="black" fill-opacity="0.1"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M122 34.584C123.766 33.8124 125 32.0503 125 30C125 27.2386 122.761 25 120 25C117.239 25 115 27.2386 115 30C115 32.0503 116.234 33.8124 118 34.584V60V64H122H141V60H122V34.584Z" fill="white" fill-opacity="0.2"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M114 46H110V68V72H114H141V68H114V46Z" fill="black" fill-opacity="0.2"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M27 103.584C25.2341 102.812 24 101.05 24 99C24 96.2386 26.2386 94 29 94C31.7614 94 34 96.2386 34 99C34 101.05 32.7659 102.812 31 103.584V129V133H27H8V129H27V103.584Z" fill="black" fill-opacity="0.2"/>
`;
