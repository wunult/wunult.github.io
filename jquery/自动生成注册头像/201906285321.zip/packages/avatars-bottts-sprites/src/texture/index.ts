import camo01 from './camo-01';
import camo02 from './camo-02';
import circuits from './circuits';
import dirty01 from './dirty-01';
import dirty02 from './dirty-02';

export default [camo01, camo02, circuits, dirty01, dirty02];
