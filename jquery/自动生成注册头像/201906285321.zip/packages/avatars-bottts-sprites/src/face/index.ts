import round01 from './round-01';
import round02 from './round-02';
import square01 from './square-01';
import square02 from './square-02';
import square03 from './square-03';
import square04 from './square-04';

export default [round01, round02, square01, square02, square03, square04];
