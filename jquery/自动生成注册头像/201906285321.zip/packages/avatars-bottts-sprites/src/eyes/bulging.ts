export default () => `
    <path fill-rule="evenodd" clip-rule="evenodd" d="M28 42C37.9411 42 46 33.9411 46 24C46 14.0589 37.9411 6 28 6C18.0589 6 10 14.0589 10 24C10 33.9411 18.0589 42 28 42Z" fill="black" fill-opacity="0.2"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M74 42C83.9411 42 92 33.9411 92 24C92 14.0589 83.9411 6 74 6C64.0589 6 56 14.0589 56 24C56 33.9411 64.0589 42 74 42Z" fill="black" fill-opacity="0.2"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M28 39C36.2843 39 43 32.2843 43 24C43 15.7157 36.2843 9 28 9C19.7157 9 13 15.7157 13 24C13 32.2843 19.7157 39 28 39Z" fill="#F1EEDA"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M74 39C82.2843 39 89 32.2843 89 24C89 15.7157 82.2843 9 74 9C65.7157 9 59 15.7157 59 24C59 32.2843 65.7157 39 74 39Z" fill="#F1EEDA"/>
    <rect x="26" y="15" width="10" height="10" rx="2" fill="black" fill-opacity="0.8"/>
    <rect x="74" y="15" width="10" height="10" rx="2" fill="black" fill-opacity="0.8"/>
`;
