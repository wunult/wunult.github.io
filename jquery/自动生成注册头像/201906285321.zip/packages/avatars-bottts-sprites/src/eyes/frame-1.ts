export default () => `
    <rect y="4" width="104" height="42" rx="4" fill="black" fill-opacity="0.8"/>
    <rect x="28" y="25" width="10" height="11" rx="2" fill="#8BDDFF"/>
    <rect x="66" y="25" width="10" height="11" rx="2" fill="#8BDDFF"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M21 4H29L12 46H4L21 4Z" fill="white" fill-opacity="0.4"/>
`;
