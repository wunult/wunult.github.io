export default () => `
    <path d="M18 19L30 17" stroke="black" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M20 31C20 27.686 22.9098 25 27 25C30.0902 25 33 27.686 33 31" stroke="black" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M86 20L74 17" stroke="black" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M84 31C84 27.686 81.0902 25 78 25C73.9098 25 71 27.686 71 31" stroke="black" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
`;
