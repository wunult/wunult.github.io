export default () => `
    <path fill-rule="evenodd" clip-rule="evenodd" d="M21 45C29.2843 45 36 38.2843 36 30C36 21.7157 29.2843 15 21 15C12.7157 15 6 21.7157 6 30C6 38.2843 12.7157 45 21 45Z" fill="white" fill-opacity="0.1"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M83 45C91.2843 45 98 38.2843 98 30C98 21.7157 91.2843 15 83 15C74.7157 15 68 21.7157 68 30C68 38.2843 74.7157 45 83 45Z" fill="white" fill-opacity="0.1"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M21 42C27.6274 42 33 36.6274 33 30C33 23.3726 27.6274 18 21 18C14.3726 18 9 23.3726 9 30C9 36.6274 14.3726 42 21 42Z" fill="white" fill-opacity="0.1"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M83 42C89.6274 42 95 36.6274 95 30C95 23.3726 89.6274 18 83 18C76.3726 18 71 23.3726 71 30C71 36.6274 76.3726 42 83 42Z" fill="white" fill-opacity="0.1"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M21 36C24.3137 36 27 33.3137 27 30C27 26.6863 24.3137 24 21 24C17.6863 24 15 26.6863 15 30C15 33.3137 17.6863 36 21 36Z" fill="white" fill-opacity="0.8"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M83 36C86.3137 36 89 33.3137 89 30C89 26.6863 86.3137 24 83 24C79.6863 24 77 26.6863 77 30C77 33.3137 79.6863 36 83 36Z" fill="white" fill-opacity="0.8"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M21 33C22.6569 33 24 31.6569 24 30C24 28.3431 22.6569 27 21 27C19.3431 27 18 28.3431 18 30C18 31.6569 19.3431 33 21 33Z" fill="white" fill-opacity="0.8"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M83 33C84.6569 33 86 31.6569 86 30C86 28.3431 84.6569 27 83 27C81.3431 27 80 28.3431 80 30C80 31.6569 81.3431 33 83 33Z" fill="white" fill-opacity="0.8"/>
`;
